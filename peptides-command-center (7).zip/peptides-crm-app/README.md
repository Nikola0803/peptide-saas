# Peptide Command Center

A multi-brand CRM/command-center for a network of WooCommerce peptide
stores, rebuilt from a readdy.ai design mockup into a real, multi-tenant
Next.js SaaS with a companion WordPress plugin.

## What's here

- **`/src`** — Next.js 14 (App Router) + TypeScript + Tailwind app.
  Multi-tenant from the schema up (`Organization` → `Brand` →
  products/orders/contacts/affiliates), so it works both as an internal
  tool and as something you resell to other store owners.
- **`/prisma/schema.prisma`** — the full data model.
- **`/prisma/seed.ts`** — demo data (3 brands, sample orders/contacts/
  affiliates) matching the original mockup, so you can click through a
  populated dashboard immediately.
- **`/wp-plugin/command-center-connector`** — the WordPress plugin.
  Installed on each brand's WooCommerce site, it:
  1. **Self-registers the site** as a new Brand using your org's API key
     (Settings → Command Center in WP admin) — this is the "automatic
     recognition of new websites": no manual step in the dashboard.
  2. **Auto-configures native WooCommerce webhooks** (order.created,
     order.updated) pointed at your Command Center, signed the same way
     WooCommerce signs any webhook (`X-WC-Webhook-Signature`).
  3. **Backfills existing products & orders** on first connect, and again
     on a twice-daily cron job as a reconciliation safety net — this is
     the "auto sync".
- **`/scripts/build-plugin-zip.ts`** — zips the plugin into
  `public/downloads/command-center-connector.zip` on every build, so the
  in-app "Download WordPress plugin" button always serves the current
  version.

## Local setup

```bash
cp .env.example .env
# edit .env — DATABASE_URL, NEXTAUTH_SECRET (openssl rand -base64 32)

npm install
npm run db:push      # creates tables from schema.prisma
npm run db:seed      # demo org + brands + orders
npm run dev
```

Sign in with the seeded demo account: `operator@example.com` /
`password123`.

## Database hosting

Decided: self-hosted Postgres on the same VPS as the app — see
"Deploying to your own VPS" below for the exact setup. The schema is
plain PostgreSQL with no vendor-specific features, so nothing here is
locked in if that ever changes.

## Connecting a WooCommerce store

1. Deploy this app somewhere reachable over HTTPS (webhooks need a real
   URL — `localhost` won't work for a live store).
2. Sign in, go to **Webhooks**, copy the **Organization API key**.
3. Download and install `command-center-connector.zip` on the
   WooCommerce site.
4. In WP admin: **Settings → Command Center** → paste the Command Center
   URL + API key → **Connect this site**.

The new brand appears on the Webhooks/Dashboard pages within seconds.

## Tracking & Pixels (conversion tracking + ad platform relay)

Each brand gets an embeddable snippet (`/tracking-pixels` page → copy the
`<script>` tag) that:

- Sets a first-party visitor-id cookie on the brand's own domain
- Auto-fires a `page_view` on load
- Exposes `window.cc('track', 'purchase', { valueCents, currency, email })`
  to call from a checkout thank-you page (or `add_to_cart`, `lead`, etc.)

Every event lands in `TrackingEvent` and is immediately relayed
server-side — fire-and-forget, doesn't block the visitor's request — to
whichever of Meta Conversions API / TikTok Events API / GA4 Measurement
Protocol the brand has configured (`TrackingConfig`, edited from the same
page). Server-side relay matters because it still attributes the
conversion even when the visitor's browser or an ad-blocker kills the
client-side pixel — that's the "share with other tools" piece.

**Not done yet here:** hashing/matching quality could go further (e.g.
phone number, first/last name for better Meta match rate), there's no
retry queue for a relay that fails (it just logs `relayError` on the
event and moves on), and the WooCommerce order webhook doesn't yet
auto-fire a server-side `purchase` event on its own — right now that only
happens if the storefront's thank-you page calls `window.cc(...)`
directly.

## Deploying to your own VPS

Runs the whole app — Next.js and Postgres — on one Ubuntu box, same
pattern as Mashiach Tech. The database never touches the public internet:
the app talks to it over `localhost`, so there's no connection pooling
complexity, no cold starts, and nothing to expose or firewall for
Postgres itself.

```bash
# --- one-time server setup ---
sudo apt update
sudo apt install -y postgresql postgresql-contrib nginx certbot python3-certbot-nginx
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs
sudo npm install -g pm2

# --- create the database + a dedicated (non-superuser) app role ---
sudo -u postgres psql -c "CREATE USER cc_app WITH PASSWORD 'a-strong-random-password';"
sudo -u postgres psql -c "CREATE DATABASE peptides_crm OWNER cc_app;"

# --- get the app onto the box (pick one) ---
# scp the zip up and unzip, or clone from your own git remote
cd /var/www/peptides-command-center
npm install

# --- configure ---
cp .env.example .env
nano .env
# DATABASE_URL / DIRECT_URL = postgresql://cc_app:<password>@localhost:5432/peptides_crm
# NEXTAUTH_URL = https://your-domain.com
# NEXTAUTH_SECRET = node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"

# --- build + first-time schema/seed ---
npm run db:push
npm run db:seed     # optional — demo data; skip once you have real brands
npm run build

# --- run it, keep it running across reboots ---
pm2 start ecosystem.config.js
pm2 save
pm2 startup        # follow the one printed command to enable on boot

# --- put nginx + TLS in front ---
sudo cp deploy/nginx.conf.example /etc/nginx/sites-available/peptides-command-center
sudo nano /etc/nginx/sites-available/peptides-command-center   # set server_name
sudo ln -s /etc/nginx/sites-available/peptides-command-center /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d your-domain.com
```

Point your domain's DNS at the VPS, and that's it — `https://your-domain.com`
is the app, and it's also the base URL you'll use for the WordPress
plugin's "Command Center URL" field and the `/pixel.js` embed snippets
(both need a real HTTPS URL, `localhost` won't work for either).

**Redeploying after a code change:**
```bash
git pull   # or re-upload
npm install
npx prisma generate
npm run build
pm2 restart peptides-command-center
```

**Backups** — this is on you now that Postgres isn't managed for you:
```bash
# simple daily dump via cron
pg_dump -U cc_app peptides_crm | gzip > /var/backups/peptides_crm_$(date +%F).sql.gz
```

## Auto-deploy on push

Every push to `main` on GitHub triggers `deploy/deploy.sh` on the VPS
automatically, via a webhook — no SSH key needs to live in GitHub, and
the deploy runs locally on the box using the lightweight `webhook` tool.

```bash
# --- one-time setup on the VPS ---
sudo apt install -y webhook
chmod +x deploy/deploy.sh

sudo mkdir -p /etc/webhook
sudo cp deploy/hooks.json.example /etc/webhook/hooks.json
sudo nano /etc/webhook/hooks.json   # replace REPLACE_WITH_A_RANDOM_SECRET

# run webhook as a persistent service
sudo tee /etc/systemd/system/webhook.service > /dev/null <<'EOF'
[Unit]
Description=webhook
After=network.target

[Service]
ExecStart=/usr/bin/webhook -hooks /etc/webhook/hooks.json -port 9000 -verbose
Restart=always
User=root

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable --now webhook
```

Then add the `/hooks/` location block from `deploy/nginx.conf.example` to
your existing nginx site config and reload it:
```bash
sudo nginx -t && sudo systemctl reload nginx
```

Finally, on GitHub: repo → **Settings → Webhooks → Add webhook**
- Payload URL: `https://your-domain.com/hooks/deploy-peptide-crm`
- Content type: `application/json`
- Secret: the same random string you put in `hooks.json`
- Events: just **push**

Push to `main` and check it worked:
```bash
sudo journalctl -u webhook -f
```
You should see the hook fire and `deploy.sh`'s output stream through.

**Note:** `deploy.sh` runs `prisma db push` on every deploy — fine while
you're actively iterating on the schema solo, but once this has real
customer data, swap that for `prisma migrate deploy` against reviewed
migrations instead, so a schema change can't silently apply on push.

## Performance

The dashboard streams in independent pieces (`Suspense` per section —
KPIs, revenue chart, funnel, recent orders, brands panel) so one slow
query doesn't block the whole page from rendering.

**If you're seeing repeated `prisma:error Error in PostgreSQL connection:
Error { kind: Closed, cause: None }` in the terminal**, that's Neon
closing an idle connection that Prisma's engine is still holding — it
happens on a *direct* connection after any pause (dev server sitting
idle for a few minutes, which is constant during normal use). Fix:
point `DATABASE_URL` at Neon's **pooled** endpoint (dashboard →
Connection Details → toggle "Pooled connection", hostname will contain
`-pooler`) with `?pgbouncer=true&connect_timeout=15` appended, and set
`DIRECT_URL` to the plain (non-pooled) connection string for
`prisma db push`/`migrate` only — see the comments in `.env.example` for
the exact shape. PgBouncer sitting in front absorbs Neon's idle
disconnects so Prisma never hits a connection it thinks is still open but
isn't.

**If you see `[next-auth][warn][NEXTAUTH_URL]`**, `NEXTAUTH_URL` in
`.env` is missing, wrong, or wasn't picked up — Next.js does not
hot-reload `.env` changes, so edit it, then fully stop and restart
`npm run dev` (not just save the file).

Beyond those two: `npm run dev` is meaningfully slower than production —
always sanity-check perceived speed with `npm run build && npm run
start` before concluding something's actually wrong. And the schema has
indexes on the columns every page actually filters/sorts by
(`Order(organizationId, placedAt)`, `Order(brandId, placedAt)`,
`Product(organizationId, masterStock)`, `Contact(organizationId,
createdAt)`, `TrackingEvent(organizationId, createdAt)`) — if query
latency is still the bottleneck on a warm, pooled connection,
`npx prisma studio` plus `EXPLAIN ANALYZE` on the slow query is the next
thing to check, not more indexes blindly.

## ShipStation (Shipping page)

Connect once (org-wide — Shipping page → paste API key/secret from
ShipStation → Account Settings → API Settings). Once connected:

- Every new order from the live WooCommerce webhook **auto-pushes to
  ShipStation** as soon as it lands (toggle this off per-org if you'd
  rather push manually)
- **"Sync all unshipped orders"** bulk-pushes anything not yet sent
- **"Refresh tracking status"** pulls back tracking numbers/carriers for
  orders ShipStation has since shipped, matched back to the right order
  by the `<brand-slug>-<order-number>` order number scheme used on push
- Per-order **"Push"** button for one-off cases

## Editing things (products, brands, affiliates)

- **Master Products** — click any row to open its detail page: edit SKU,
  chemical name, COGS, and master stock; add/remove COA documents; delete
  the product entirely (order history keeps the SKU/name as plain text
  even after the catalog row is gone, so past orders don't break)
- **Webhooks page** — add any website by URL (name + URL, no plugin
  needed), then prove ownership with a paste-this-code-and-click-Verify
  flow (same idea as Google Search Console — the code just needs to
  appear anywhere in the homepage's HTML, a meta tag or plain footer text
  both work). Plugin-registered brands skip this since possessing the org
  API key is already proof enough. **Remove any brand**, including the
  seeded demo ones, which cascades to delete its orders/contacts/product
  mappings/tracking data too.
- **Affiliates** — "New affiliate" now actually creates one

## Batch/lot tracking & recalls

Any product can have batches recorded (Master Products → a product's
detail page → "Batches / lots"): lot number, quantity received, optional
COA URL, optional expiry date. From then on, **every order that comes in
through the live WooCommerce webhook auto-allocates against the oldest
active batch with stock left (FIFO)** — that allocation is what makes a
recall list possible later, since each `OrderItem` row remembers exactly
which lot fulfilled it.

If a batch ever needs recalling: open it, click "Recall this batch," give
a reason. That instantly turns into an actionable report at
`/products/[id]/lots/[lotId]/recall` — every affected order, customer
email, brand, and quantity — and a red banner appears at the top of the
Dashboard until it's resolved (can't be missed, doesn't wait behind any
loading state).

Products without any lots recorded skip all of this silently — lot
tracking is opt-in per product, not required for orders to process.

## Invoices, receipts, refunds/chargebacks, order notes

**Order detail page** (new — Orders list rows now link to it): items,
a notes thread, a fraud-flag toggle with a reason, and a refund/chargeback
log with a won/lost resolution workflow for chargebacks.

**Receipts** — every order gets one for free, no setup: "Download
receipt" on its detail page streams a PDF generated on the spot from the
order's own data (itemized, dated, with the standard research-use-only
disclaimer footer) — nothing stored, nothing to configure.

**Invoices** — a separate, real lifecycle (draft → sent → paid/overdue/
void) for wholesale. Create one from scratch (`/invoices/new`) or straight
from an order ("Create invoice" button on its detail page, which
pre-fills customer info and line items from that order). Supports PO
numbers, due dates, tax, and notes/terms (e.g. "Net 30"). Invoice numbers
are sequential per organization (`INV-000123`).

**Chargeback rate** — a stat card on the Orders page (all-time
chargebacks ÷ all-time orders) — the number that actually determines
whether your payment processor keeps your account open.

Both PDFs are generated with `@react-pdf/renderer`, rendered server-side
to a buffer (not streamed as a raw Node stream — that doesn't work
reliably as a Next.js response body, worth knowing if you ever touch
`src/lib/billing-pdf.tsx`).

**Gaps worth knowing about:** invoice numbering is a simple count-based
scheme (`count + 1`), not race-safe under concurrent invoice creation —
fine at low volume, worth a real sequence/lock before this sees heavy
concurrent use. The new-invoice form has a fixed number of line-item
rows (8) rather than a dynamic add/remove list. Chargeback disputes
don't auto-attach the receipt PDF anywhere (e.g. to an email) — that's a
manual step for now.

## What's NOT built yet

- **Multi-org signup/onboarding flow.** Right now organizations only
  exist via the seed script or direct DB inserts — there's no public
  "create your account" page. Needed before this can actually be sold.
- **Billing** (Stripe subscriptions tied to `Organization.plan`).
- **Variable-product / variation support** in the plugin's product sync
  (currently simple products only, matched by SKU).
- **Order edits/refunds after the fact** — the webhook handler upserts an
  order's status and totals on re-delivery, but doesn't currently re-diff
  line items, so a partial refund that changes quantities won't be
  reflected in `OrderItem` rows.
- **Shipping** is now real (ShipStation) — see above. **Payments, Email
  Marketing, Social Analytics, AI Blog Tool, Reddit Marketing** are still
  placeholders with a description of what they'll do, no logic behind
  them yet.
- **ShipStation gaps**: no per-brand ShipStation account support (one
  connection per organization only), no handling of partial shipments
  (multiple packages per order), and pushed orders don't include a
  shipping address yet — add `payload.shipping` from the WooCommerce
  webhook into `pushOrderToShipStation`'s `shipTo` field before relying on
  this for real label printing.
- **Real merchant fee configuration** — the profit calculation assumes a
  flat 2.9% + $0.30 processor fee; make this configurable per brand
  before trusting the net profit numbers.
- **Team invitations** — `Membership`/`Role` exist in the schema, but
  there's no UI to invite a second user into an organization yet.
