import { PrismaClient } from "@prisma/client";

// Standard Next.js singleton pattern — prevents exhausting DB connections
// from hot-reload creating a new PrismaClient on every save in dev.
const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["warn", "error"] : ["error"],
  });

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
